# gmms: Ground Motion Models (GMMs) and supporting tools

This repository provides a ground motion models (GMMs) and supporting tools coded in Python and Cython. By default, the Python version of the library is loaded, but the Cython can be selected when desired (see Examples). 
The GMMs available are listed below, and the tools include codes for computing the distances required in GMMs. 

| Ground motion model             | Ground motion intensity measure                                             |
|---------------------------------|-----------------------------------------------------------------------------|
| Campbell and Bozorgnia (2010)   | Geometric mean horizontal standardized cumulative absolute velocity (CAVgm) |
| Campbell and Bozorgnia (2011)   | Damage-potential cumulative absolute velocity (CAVdp)                       |
| Campbell and Bozorgnia (2019)   | Arias intensity (Ia)                                                        |
| Campbell and Bozorgnia (2019)   | Cumulative absolute velocity (CAV)                                          |
| Foulser-Piggott and Goda (2015) | Arias Intensity (Ia)                                                        |
| Foulser-Piggott and Goda (2015) | Cumulative absolute velocity (CAV)                                          |


## Example
Three examples on Jupyter Notebooks are presented:
- [Example 1 (Python backend)](https://github.com/RPretellD/gmms/blob/main/examples/Example1_Python.ipynb): Use of Campbell and Bozorgnia models for the 1989 Loma Prieta Earthquake (single-segment fault). 
- [Example 1 (Cython backend)](https://github.com/RPretellD/gmms/blob/main/examples/Example1_Cython.ipynb): Use of Campbell and Bozorgnia models for the 1989 Loma Prieta Earthquake (single-segment fault). 
- [Example 2 (Python backend)](https://github.com/RPretellD/gmms/blob/main/examples/Example2_Python.ipynb): Use of Campbell and Bozorgnia models for the 2023 Pazarcik Earthquake (multi-segment fault). 
- [Example 2 (Cython backend)](https://github.com/RPretellD/gmms/blob/main/examples/Example2_Cython.ipynb): Use of Campbell and Bozorgnia models for the 2023 Pazarcik Earthquake (multi-segment fault). 
- [Example 3 (Python backend)](https://github.com/RPretellD/gmms/blob/main/examples/Example3_Python.ipynb): Use of the Foulser-Piggott and Goda models for the 2003 Tokachi Earthquake. 
- [Example 3 (Cython backend)](https://github.com/RPretellD/gmms/blob/main/examples/Example3_Cython.ipynb): Use of the Foulser-Piggott and Goda models for the 2003 Tokachi Earthquake. 


## Acknowledgements
The codes for the estimation of Joyner-Boore and rupture distances are based on Pengfei Wang's [R implementations](https://github.com/wltcwpf/RPSHA/blob/main/R/distance_calc.R).


## References
> Campbell, K.W., and Bozorgnia, Y. (2010). "A ground motion prediction equation for the horizontal component of cumulative absolute velocity (CAV) based on the PEER-NGA strong motion database." Earthquake Spectra 26(3): 635–650. 

> Campbell, K.W., and Bozorgnia, Y. (2011). "Prediction equations for the standardized version of cumulative absolute velocity as adapted for use in the shutdown of U.S. nuclear power plants." Nuclear Engineering and Design 241(2011): 2558–2569. 

> Campbell, K.W., and Bozorgnia, Y. (2019). "Ground motion models for the horizontal components of Arias intensity (AI) and cumulative absolute velocity (CAV) using the NGA-West2 Database." Earthquake Spectra 35(3): 1289–1310. 

> Foulser‐Piggott, R., and Goda, K. (2015). "Ground‐motion prediction models for Arias intensity and cumulative absolute velocity for Japanese earthquakes considering single‐station sigma and within‐event spatial correlation." Bulletin of the Seismological Society of America 105(4): 1903–1918. 


## Citation
> Pretell, R. (2026). gmms: Ground motion models and supporting tools (v1.0.0). Zenodo. http://doi.org/10.5281/zenodo.10127854<br>

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.10127854.svg)](https://doi.org/10.5281/zenodo.10127854)


## Contact
For any questions or comments, contact Renmin Pretell (rpretell at unr dot edu).